import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // The Command Center builds in a staging copy, swaps the finished .next into
  // place and restarts the app, so nothing here needs to know about deploys.
  reactStrictMode: true,

  async redirects() {
    // The vanilla build was two static files. Anyone holding an old
    // link — a PM with the enquiry form bookmarked, most of all —
    // lands where they expect.
    return [
      { source: "/index.html", destination: "/", permanent: true },
      { source: "/outreach.html", destination: "/outreach", permanent: true },
    ];
  },

  async headers() {
    return [
      {
        // The service worker must not be served from a stale cache, or a
        // bad one can outlive its own replacement.
        source: "/sw.js",
        headers: [
          { key: "Cache-Control", value: "no-cache, no-store, must-revalidate" },
          { key: "Service-Worker-Allowed", value: "/" },
        ],
      },
    ];
  },
};

export default nextConfig;
