"use client";

/* Registers the service worker that makes the app installable and
   gives it something to show with no signal. Deliberately quiet:
   a registration that fails is not worth a message to someone
   standing next to a truck at 5am. */

import { useEffect } from "react";

export function ServiceWorker() {
  useEffect(() => {
    if (!("serviceWorker" in navigator)) return;
    if (process.env.NODE_ENV !== "production") return;
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);
  return null;
}
